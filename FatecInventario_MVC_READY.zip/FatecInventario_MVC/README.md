# FatecInventario MVC — br.edu.fatecpg

## Como rodar
1) File → Open → selecione a pasta do projeto.
2) Aceite o import do Maven.
3) Rode `br.edu.fatecpg.view.Menu` (botão ▶).

## Tecnologias
Jackson (ObjectMapper + JsonNode), Regex (Pattern/Matcher), Enum, Optional, Persistência JSON.
