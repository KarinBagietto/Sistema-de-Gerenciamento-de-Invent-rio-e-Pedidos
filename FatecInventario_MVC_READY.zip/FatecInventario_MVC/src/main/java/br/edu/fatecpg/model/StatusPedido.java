package br.edu.fatecpg.model;

public enum StatusPedido {
    NOVO("Novo"),
    PROCESSANDO("Processando"),
    ENVIADO("Enviado"),
    ENTREGUE("Entregue"),
    CANCELADO("Cancelado");

    private final String descricao;
    StatusPedido(String descricao) { this.descricao = descricao; }
    public String getDescricao() { return descricao; }
}
