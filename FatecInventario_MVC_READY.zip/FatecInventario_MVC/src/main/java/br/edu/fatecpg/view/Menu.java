package br.edu.fatecpg.view;

import br.edu.fatecpg.controller.SistemaInventario;

public class Menu {
    public static void main(String[] args) {
        new SistemaInventario().start();
    }
}
