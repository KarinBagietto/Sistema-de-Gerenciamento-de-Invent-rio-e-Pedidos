package br.edu.fatecpg.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Pedido {
    private String id;
    private String nomeCliente;
    private String emailCliente;
    private StatusPedido status;
    private List<ItemPedido> itens = new ArrayList<>();

    public Pedido() {}

    public Pedido(String id, String nomeCliente, String emailCliente) {
        this.id = id;
        this.nomeCliente = nomeCliente;
        this.emailCliente = emailCliente;
        this.status = StatusPedido.NOVO;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getNomeCliente() { return nomeCliente; }
    public void setNomeCliente(String nomeCliente) { this.nomeCliente = nomeCliente; }
    public String getEmailCliente() { return emailCliente; }
    public void setEmailCliente(String emailCliente) { this.emailCliente = emailCliente; }
    public StatusPedido getStatus() { return status; }
    public void setStatus(StatusPedido status) { this.status = status; }
    public List<ItemPedido> getItens() { return itens; }
    public void setItens(List<ItemPedido> itens) { this.itens = itens; }

    public void addItem(ItemPedido item) { itens.add(item); }
    public double getValorTotal() { return itens.stream().mapToDouble(ItemPedido::getTotal).sum(); }

    @Override
    public String toString() {
        return "ID: " + id + ", Cliente: " + nomeCliente + ", Status: " + status.getDescricao() +
               ", Total: R$" + String.format("%.2f", getValorTotal());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Pedido)) return false;
        Pedido pedido = (Pedido) o;
        return java.util.Objects.equals(getId(), pedido.getId());
    }
    @Override
    public int hashCode() { return java.util.Objects.hash(getId()); }
}
