package br.edu.fatecpg.controller;

import br.edu.fatecpg.model.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

public class SistemaInventario {
    private final Scanner scanner = new Scanner(System.in);
    private final ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    private final Map<String, Produto> produtos = new HashMap<>();
    private final Map<String, Pedido> pedidos = new HashMap<>();
    private static final String PRODUTOS_FILE = "produtos.json";
    private static final String PEDIDOS_FILE = "pedidos.json";
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$");

    public void start() {
        carregarProdutos();
        carregarPedidos();
        while (true) {
            exibirMenu();
            String opcao = scanner.nextLine();
            try {
                switch (Integer.parseInt(opcao)) {
                    case 1 -> listarProdutos();
                    case 2 -> adicionarProduto();
                    case 3 -> buscarProduto();
                    case 4 -> criarPedido();
                    case 5 -> listarPedidos();
                    case 6 -> verDetalhesPedido();
                    case 7 -> atualizarStatus();
                    case 8 -> { salvarTudo(); return; }
                    default -> System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro: entrada inválida!");
            }
        }
    }

    private void exibirMenu() {
        System.out.println("\n=== SISTEMA DE INVENTÁRIO ===");
        System.out.println("1. Listar Produtos");
        System.out.println("2. Adicionar/Atualizar Produto");
        System.out.println("3. Buscar Produto por ID");
        System.out.println("4. Criar Pedido");
        System.out.println("5. Listar Pedidos");
        System.out.println("6. Detalhes do Pedido");
        System.out.println("7. Atualizar Status do Pedido");
        System.out.println("8. Sair");
        System.out.print("Opção: ");
    }

    private void carregarProdutos() {
        try {
            File file = new File(PRODUTOS_FILE);
            if (!file.exists()) return;
            JsonNode node = mapper.readTree(file);
            for (JsonNode n : node) {
                Produto p = mapper.treeToValue(n, Produto.class);
                produtos.put(p.getId(), p);
            }
        } catch (IOException e) { System.out.println("Erro ao carregar produtos."); }
    }

    private void carregarPedidos() {
        try {
            File file = new File(PEDIDOS_FILE);
            if (!file.exists()) return;
            JsonNode node = mapper.readTree(file);
            for (JsonNode n : node) {
                Pedido p = mapper.treeToValue(n, Pedido.class);
                pedidos.put(p.getId(), p);
            }
        } catch (IOException e) { System.out.println("Erro ao carregar pedidos."); }
    }

    private void salvarTudo() {
        try { mapper.writeValue(new File(PRODUTOS_FILE), produtos.values()); } catch (Exception ignored) {}
        try { mapper.writeValue(new File(PEDIDOS_FILE), pedidos.values()); } catch (Exception ignored) {}
        System.out.println("Dados salvos. Saindo...");
    }

    private void listarProdutos() {
        if (produtos.isEmpty()) System.out.println("Sem produtos.");
        else produtos.values().forEach(System.out::println);
    }

    private void adicionarProduto() {
        System.out.print("ID: ");
        String id = scanner.nextLine().toUpperCase();
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Preço: ");
        double preco = Double.parseDouble(scanner.nextLine().replace(',', '.'));
        System.out.print("Quantidade: ");
        int qtde = Integer.parseInt(scanner.nextLine());
        Produto novo = new Produto(id, nome, preco, qtde);
        produtos.merge(id, novo, (a, b) -> {
            a.setNome(b.getNome());
            a.setPreco(b.getPreco());
            a.setQuantidade(a.getQuantidade() + b.getQuantidade());
            return a;
        });
        System.out.println("Produto salvo.");
    }

    private void buscarProduto() {
        System.out.print("Digite o ID: ");
        String id = scanner.nextLine().toUpperCase();
        Optional.ofNullable(produtos.get(id))
                .ifPresentOrElse(System.out::println, () -> System.out.println("Produto não encontrado."));
    }

    private void criarPedido() {
        String idPedido = "PED" + (pedidos.size() + 1);
        System.out.print("Cliente: ");
        String nome = scanner.nextLine();

        String email;
        while (true) {
            System.out.print("E-mail: ");
            email = scanner.nextLine();
            if (EMAIL_PATTERN.matcher(email).matches()) break;
            System.out.println("E-mail inválido! Tente novamente (ex: cliente@dominio.com)");
        }

        Pedido pedido = new Pedido(idPedido, nome, email);
        while (true) {
            System.out.print("Produto (ou FIM): ");
            String id = scanner.nextLine().toUpperCase();
            if (id.equals("FIM")) break;
            Produto p = produtos.get(id);
            if (p == null) { System.out.println("Produto não existe."); continue; }
            System.out.print("Quantidade: ");
            int q;
            try { q = Integer.parseInt(scanner.nextLine()); }
            catch (NumberFormatException e) { System.out.println("Quantidade inválida."); continue; }
            if (p.getQuantidade() < q) { System.out.println("Estoque insuficiente."); continue; }
            pedido.addItem(new ItemPedido(p, q));
            p.setQuantidade(p.getQuantidade() - q);
        }
        if (!pedido.getItens().isEmpty()) { pedidos.put(idPedido, pedido); System.out.println("✅ Pedido criado com sucesso!"); }
        else System.out.println("❌ Nenhum item adicionado. Pedido cancelado.");
    }

    private void listarPedidos() {
        if (pedidos.isEmpty()) System.out.println("Nenhum pedido.");
        else pedidos.values().forEach(System.out::println);
    }

    private void verDetalhesPedido() {
        System.out.print("ID do pedido: ");
        Pedido p = pedidos.get(scanner.nextLine().toUpperCase());
        if (p == null) { System.out.println("Pedido não encontrado."); return; }
        System.out.println(p);
        p.getItens().forEach(System.out::println);
    }

    private void atualizarStatus() {
        System.out.print("ID do pedido: ");
        Pedido p = pedidos.get(scanner.nextLine().toUpperCase());
        if (p == null) { System.out.println("Pedido não encontrado."); return; }
        StatusPedido[] s = StatusPedido.values();
        for (int i = 0; i < s.length; i++) System.out.println((i+1) + ". " + s[i].getDescricao());
        System.out.print("Novo status: ");
        int op = Integer.parseInt(scanner.nextLine());
        if (op >= 1 && op <= s.length) p.setStatus(s[op-1]);
        System.out.println("Status atualizado.");
    }
}
