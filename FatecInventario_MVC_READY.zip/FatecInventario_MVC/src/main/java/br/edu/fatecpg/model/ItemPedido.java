package br.edu.fatecpg.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ItemPedido {
    private Produto produto;
    private int quantidade;

    public ItemPedido() {}

    public ItemPedido(Produto produto, int quantidade) {
        this.produto = new Produto(produto.getId(), produto.getNome(), produto.getPreco(), 0);
        this.quantidade = quantidade;
    }

    public Produto getProduto() { return produto; }
    public void setProduto(Produto produto) { this.produto = produto; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

    @JsonIgnore
    public double getTotal() { return produto.getPreco() * quantidade; }

    @Override
    public String toString() {
        return produto.getNome() + " (ID: " + produto.getId() + ") - Qtde: " + quantidade +
               " - Preço Unit.: R$" + String.format("%.2f", produto.getPreco()) +
               " - Total: R$" + String.format("%.2f", getTotal());
    }
}
